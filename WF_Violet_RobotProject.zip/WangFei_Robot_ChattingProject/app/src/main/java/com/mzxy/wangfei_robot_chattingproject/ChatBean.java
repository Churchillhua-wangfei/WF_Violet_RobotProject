package com.mzxy.wangfei_robot_chattingproject;

public class ChatBean {
	public static final int SEND = 1; // 发送消息
	public static final int RECEIVE = 2; // 接受消息

	private int state; // 消息的状态（是接受还是发送）
	private String message; // 消息的内容


	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
